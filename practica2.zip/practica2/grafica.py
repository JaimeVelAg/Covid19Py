from covid import Covid
import json

covid = Covid()
covid.get_data()

cases = covid.get_status_by_country_name("mexico")

print(cases)
print(cases['deaths'])